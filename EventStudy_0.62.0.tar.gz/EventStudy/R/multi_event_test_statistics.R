#' Cross-Sectional T Test (CSectTTest)
#'
#' The Cross-Sectional Test (CSect T) is a statistical tool employed in event
#' studies to evaluate the null hypothesis that the average abnormal return at
#' the event date is zero. The test statistic is distributed as \eqn{t_{N-1}}, where
#' N is the number of events in that group.
#'
#' See also \url{https://eventstudy.de/statistics/aar_caar_statistics.html}
#'
#' @export
CSectTTest <- R6Class("CSectTTest",
                   inherit = TestStatisticBase,
                   public = list(
                     #' @field name Short code of the test statistic.
                     name = 'CSectT',
                     #' @description
                     #' Computes the AAR/CAAR cross-sectional t test statistics.
                     #'
                     #' @param data_tbl The data for a multiple event with
                     #' calculated abnormal returns.
                     #' @param model The fitted model: not necessary for this
                     #' test statistics.
                     compute = function(data_tbl, model) {
                       # AAR & AAR T Test
                       aar_caar_stats = data_tbl %>%
                         dplyr::filter(event_window == 1) %>%
                         dplyr::group_by(relative_index) %>%
                         dplyr::summarise(aar            = mean(abnormal_returns, na.rm = TRUE),
                                          n_events       = dplyr::n(),
                                          n_valid_events = sum(!is.na(abnormal_returns)),
                                          n_pos          = sum(abnormal_returns >= 0, na.rm = TRUE),
                                          n_neg          = sum(abnormal_returns < 0, na.rm = TRUE),
                                          aar_t          = {
                                            sd_ar <- sd(abnormal_returns, na.rm = TRUE)
                                            if (is.finite(sd_ar) && sd_ar > 0) sqrt(n_valid_events) * aar / sd_ar else NA_real_
                                          },
                                          .groups = "drop")

                       # Calculate SD_CAAR for each window
                       sd_caar = data_tbl %>%
                         dplyr::filter(event_window == 1) %>%
                         dplyr::select(event_id, relative_index, abnormal_returns) %>%
                         dplyr::group_by(event_id) %>%
                         dplyr::mutate(car = cumsum(dplyr::coalesce(abnormal_returns, 0))) %>%
                         dplyr::group_by(relative_index) %>%
                         dplyr::summarise(sd_caar = sd(car, na.rm=TRUE))

                       # Finally, the t statistic for CAAR and each window is calculated
                       aar_caar_stats = aar_caar_stats %>%
                         dplyr::mutate(caar = cumsum(dplyr::coalesce(aar, 0))) %>%
                         dplyr::left_join(sd_caar, by="relative_index") %>%
                         dplyr::mutate(caar_t = ifelse(is.finite(sd_caar) & sd_caar > 0,
                                                        sqrt(n_valid_events) * caar / sd_caar,
                                                        NA_real_)) %>%
                         dplyr::select(-sd_caar)

                       aar_caar_stats$car_window = stringr::str_c("[", aar_caar_stats$relative_index[1], ", ", aar_caar_stats$relative_index, "]")

                       aar_caar_stats
                     }
                   )
)


#' Patell or Standardized Residual Test (PatellZTest)
#'
#' The Patell or Standardized Residual Test is a statistical tool employed in event
#' studies to evaluate the null hypothesis that the average abnormal return at
#' the event date is zero. The test statistics is approximately distributed as
#' N(0, 1).
#'
#' See also \url{https://eventstudy.de/statistics/aar_caar_statistics.html}
#'
#' @export
PatellZTest <- R6Class("PatellZTest",
                      inherit = TestStatisticBase,
                      public = list(
                        #' @field name Short code of the test statistic.
                        name = 'PatellZ',
                        #' @description
                        #' Computes the Patell Z test statistics for multiple events.
                        #'
                        #' @param data_tbl The data for a multiple event with
                        #' calculated abnormal returns.
                        #' @param model The fitted model.
                        compute = function(data_tbl, model) {
                          # Extract number of estimated parameters (k) from model df
                          # df = m - k, so k = m - df. Default k=2 for MarketModel.
                          model_k = model %>%
                            dplyr::mutate(k = purrr::map_dbl(model, function(x) {
                              df <- x$statistics$degree_of_freedom
                              resid <- x$statistics$residuals
                              if (!is.null(df) && !is.null(resid) &&
                                  length(df) == 1 && is.finite(df)) {
                                length(resid) - df
                              } else {
                                2L  # default: intercept + slope (MarketModel)
                              }
                            }))
                          # Use median k across firms (should be same for all)
                          k_param <- stats::median(model_k$k)

                          # Key all per-event quantities on event_id, not
                          # firm_symbol: each event is fit separately and a firm
                          # may recur across events.
                          sd_asar = data_tbl %>%
                            dplyr::filter(estimation_window == 1) %>%
                            dplyr::group_by(event_id) %>%
                            dplyr::summarise(m = dplyr::n(), .groups = "drop") %>%
                            dplyr::mutate(
                              Q_i = ifelse(
                                m > k_param + 2,
                                (m - k_param) / (m - k_param - 2),
                                1  # fallback: insufficient obs for Q_i adjustment
                              )
                            )

                          # Extract forecast error corrected sigma (vector per firm)
                          fec_sigma = model %>%
                            dplyr::mutate(fec_sigma = purrr::map(model, .f=function(x) {
                              fec <- x$statistics$forecast_error_corrected_sigma
                              if (is.null(fec)) NA_real_ else fec
                            })) %>%
                            dplyr::select(event_id, fec_sigma) %>%
                            tidyr::unnest(fec_sigma) %>%
                            dplyr::group_by(event_id) %>%
                            dplyr::mutate(day_index = dplyr::row_number()) %>%
                            dplyr::ungroup()

                          # Standardize abnormal returns by forecast-error-corrected sigma
                          aar_caar_stats_tmp = data_tbl %>%
                            dplyr::filter(event_window == 1) %>%
                            dplyr::group_by(event_id) %>%
                            dplyr::mutate(day_index = dplyr::row_number()) %>%
                            dplyr::ungroup() %>%
                            dplyr::left_join(fec_sigma, by = c("event_id", "day_index")) %>%
                            dplyr::mutate(standardized_abnormal_returns = abnormal_returns / fec_sigma)

                          # AAR & AAR Z Test
                          # WR-01 fix: exclude degenerate events (all-NA fec_sigma) from Q_total.
                          # Degenerate events contribute Q_i = 1 (the fallback at the sd_asar step)
                          # inflating the denominator and deflating valid-event z-scores. Only sum
                          # Q_i for events where at least one fec_sigma value is finite.
                          valid_event_ids <- fec_sigma %>%
                            dplyr::group_by(event_id) %>%
                            dplyr::summarise(.valid = any(is.finite(fec_sigma)), .groups = "drop") %>%
                            dplyr::filter(.valid) %>%
                            dplyr::pull(event_id)
                          sd_asar_valid <- sd_asar %>% dplyr::filter(event_id %in% valid_event_ids)
                          Q_total = sqrt(sum(sd_asar_valid$Q_i))

                          aar_caar_stats = aar_caar_stats_tmp %>%
                            dplyr::group_by(relative_index) %>%
                            dplyr::summarise(aar            = mean(abnormal_returns, na.rm = TRUE),
                                             sum_sar        = sum(standardized_abnormal_returns, na.rm = TRUE),
                                             n_events       = dplyr::n(),
                                             n_valid_events = sum(!is.na(abnormal_returns)),
                                             n_pos          = sum(abnormal_returns >= 0, na.rm = TRUE),
                                             n_neg          = sum(abnormal_returns < 0, na.rm = TRUE),
                                             # STATS-04: n_events == 1 yields a statistically invalid
                                             # z-score (the Patell approximation requires N >= 2 for
                                             # the variance to be estimable). Return NA instead of a
                                             # finite-but-invalid number.
                                             aar_z          = ifelse(n_valid_events <= 1,
                                                                     NA_real_,
                                                                     sum_sar / Q_total),
                                             .groups = "drop") %>%
                            dplyr::select(-sum_sar)

                          sd_caar = aar_caar_stats_tmp %>%
                            dplyr::left_join(sd_asar, by = "event_id") %>%
                            dplyr::group_by(event_id) %>%
                            dplyr::mutate(csar = cumsum(dplyr::coalesce(standardized_abnormal_returns, 0)),
                                          n    = dplyr::row_number(),
                                          csar = csar / sqrt(n * .data$Q_i)) %>%
                            dplyr::group_by(relative_index) %>%
                            dplyr::summarise(caar_z = 1 / sqrt(dplyr::n()) * sum(csar, na.rm = TRUE))

                          aar_caar_stats = aar_caar_stats %>%
                            dplyr::mutate(caar = cumsum(dplyr::coalesce(aar, 0))) %>%
                            dplyr::left_join(sd_caar, by = "relative_index") %>%
                            # STATS-04: propagate n_events==1 guard to caar_z as well.
                            dplyr::mutate(caar_z = ifelse(n_valid_events <= 1, NA_real_, caar_z))

                          aar_caar_stats$car_window = stringr::str_c("[", aar_caar_stats$relative_index[1], ", ", aar_caar_stats$relative_index, "]")
                          aar_caar_stats
                        }
                      )
)


#' Sign Test for Multiple Events
#'
#' Tests whether the proportion of positive abnormal returns differs
#' significantly from 0.5 under the null hypothesis. The test statistic
#' is approximately distributed as N(0, 1).
#'
#' @export
SignTest <- R6Class("SignTest",
                    inherit = TestStatisticBase,
                    public = list(
                      #' @field name Short code of the test statistic.
                      name = 'SignT',
                      #' @description
                      #' Computes the sign test for multiple events.
                      #'
                      #' @param data_tbl The data for a multiple event with
                      #' calculated abnormal returns.
                      #' @param model The fitted model (unused).
                      compute = function(data_tbl, model) {
                        aar_stats = data_tbl %>%
                          dplyr::filter(event_window == 1) %>%
                          dplyr::group_by(relative_index) %>%
                          dplyr::summarise(
                            aar            = mean(abnormal_returns, na.rm = TRUE),
                            n_events       = dplyr::n(),
                            n_valid_events = sum(!is.na(abnormal_returns)),
                            n_pos          = sum(abnormal_returns > 0, na.rm = TRUE),
                            n_neg          = sum(abnormal_returns <= 0, na.rm = TRUE),
                            .groups = "drop"
                          ) %>%
                          dplyr::mutate(
                            # Sign test: (n_pos - 0.5*N) / (0.5*sqrt(N))
                            # STATS-04: n_events == 1 produces a finite-but-statistically-invalid
                            # z (the sign test needs at least 2 observations to be meaningful).
                            # Guard: require n_valid_events >= 2, not just > 0.
                            sign_z = ifelse(n_valid_events >= 2,
                                            (n_pos - 0.5 * n_valid_events) / (0.5 * sqrt(n_valid_events)),
                                            NA_real_),
                            caar   = cumsum(dplyr::coalesce(aar, 0))
                          )

                        # Cumulative sign test
                        cum_sign = data_tbl %>%
                          dplyr::filter(event_window == 1) %>%
                          dplyr::select(event_id, relative_index, abnormal_returns) %>%
                          dplyr::group_by(event_id) %>%
                          dplyr::mutate(car = cumsum(dplyr::coalesce(abnormal_returns, 0))) %>%
                          dplyr::group_by(relative_index) %>%
                          dplyr::summarise(
                            n_pos_car = sum(car > 0, na.rm = TRUE),
                            n_valid   = sum(!is.na(car)),
                            # WR-02 fix: guard n_valid >= 2, mirroring the point-in-time sign_z guard.
                            # When n_valid == 1 the formula yields a finite but statistically
                            # meaningless number. Return NA instead (same pattern as sign_z).
                            csign_z   = ifelse(n_valid >= 2,
                                               (n_pos_car - 0.5 * n_valid) / (0.5 * sqrt(n_valid)),
                                               NA_real_),
                            .groups = "drop"
                          )

                        aar_stats = aar_stats %>%
                          dplyr::left_join(cum_sign %>% dplyr::select(relative_index, csign_z),
                                           by = "relative_index")

                        aar_stats$car_window = stringr::str_c("[", aar_stats$relative_index[1], ", ", aar_stats$relative_index, "]")
                        aar_stats
                      }
                    )
)


#' Generalized Sign Test (Cowan 1992)
#'
#' Adjusts the sign test for the expected proportion of positive abnormal
#' returns estimated from the estimation window, rather than assuming 0.5.
#' This accounts for asymmetry in the return distribution.
#'
#' @export
GeneralizedSignTest <- R6Class("GeneralizedSignTest",
                               inherit = TestStatisticBase,
                               public = list(
                                 #' @field name Short code of the test statistic.
                                 name = 'GSignT',
                                 #' @description
                                 #' Computes the generalized sign test for multiple events.
                                 #'
                                 #' @param data_tbl The data for a multiple event with
                                 #' calculated abnormal returns.
                                 #' @param model The fitted model (unused).
                                 compute = function(data_tbl, model) {
                                   # Estimate p_hat from estimation window
                                   p_hat_by_firm = data_tbl %>%
                                     dplyr::filter(estimation_window == 1) %>%
                                     dplyr::group_by(firm_symbol) %>%
                                     dplyr::summarise(
                                       p_hat = mean(abnormal_returns > 0, na.rm = TRUE),
                                       .groups = "drop"
                                     )

                                   # Average p_hat across firms
                                   p_hat = mean(p_hat_by_firm$p_hat, na.rm = TRUE)

                                   aar_stats = data_tbl %>%
                                     dplyr::filter(event_window == 1) %>%
                                     dplyr::group_by(relative_index) %>%
                                     dplyr::summarise(
                                       aar            = mean(abnormal_returns, na.rm = TRUE),
                                       n_events       = dplyr::n(),
                                       n_valid_events = sum(!is.na(abnormal_returns)),
                                       n_pos          = sum(abnormal_returns > 0, na.rm = TRUE),
                                       n_neg          = sum(abnormal_returns <= 0, na.rm = TRUE),
                                       .groups = "drop"
                                     ) %>%
                                     dplyr::mutate(
                                       gsign_z = {
                                         denom <- sqrt(n_valid_events * p_hat * (1 - p_hat))
                                         ifelse(is.finite(denom) & denom > 0,
                                                (n_pos - n_valid_events * p_hat) / denom,
                                                NA_real_)
                                       },
                                       caar = cumsum(dplyr::coalesce(aar, 0))
                                     )

                                   # Cumulative generalized sign test
                                   cum_gsign = data_tbl %>%
                                     dplyr::filter(event_window == 1) %>%
                                     dplyr::select(event_id, relative_index, abnormal_returns) %>%
                                     dplyr::group_by(event_id) %>%
                                     dplyr::mutate(car = cumsum(dplyr::coalesce(abnormal_returns, 0))) %>%
                                     dplyr::group_by(relative_index) %>%
                                     dplyr::summarise(
                                       n_pos_car = sum(car > 0, na.rm = TRUE),
                                       n_valid   = sum(!is.na(car)),
                                       cgsign_z  = {
                                         denom <- sqrt(n_valid * p_hat * (1 - p_hat))
                                         ifelse(is.finite(denom) & denom > 0,
                                                (n_pos_car - n_valid * p_hat) / denom,
                                                NA_real_)
                                       },
                                       .groups = "drop"
                                     )

                                   aar_stats = aar_stats %>%
                                     dplyr::left_join(cum_gsign %>% dplyr::select(relative_index, cgsign_z),
                                                      by = "relative_index")

                                   aar_stats$car_window = stringr::str_c("[", aar_stats$relative_index[1], ", ", aar_stats$relative_index, "]")
                                   aar_stats
                                 }
                               )
)


#' Rank Test (Corrado 1989)
#'
#' Non-parametric rank test for event studies. Ranks abnormal returns
#' across the combined estimation and event windows, which is robust
#' to non-normality of abnormal returns.
#'
#' @export
RankTest <- R6Class("RankTest",
                    inherit = TestStatisticBase,
                    public = list(
                      #' @field name Short code of the test statistic.
                      name = 'RankT',
                      #' @description
                      #' Computes the Corrado rank test for multiple events.
                      #'
                      #' @param data_tbl The data for a multiple event with
                      #' calculated abnormal returns.
                      #' @param model The fitted model (unused).
                      compute = function(data_tbl, model) {
                        # Rank abnormal returns within each firm across combined windows
                        ranked_data = data_tbl %>%
                          dplyr::filter(estimation_window == 1 | event_window == 1) %>%
                          dplyr::group_by(firm_symbol) %>%
                          dplyr::mutate(
                            total_obs = dplyr::n(),
                            ar_rank   = rank(abnormal_returns, na.last = "keep"),
                            # Center ranks: K_it = rank / (T+1) - 0.5
                            centered_rank = ar_rank / (total_obs + 1) - 0.5
                          ) %>%
                          dplyr::ungroup()

                        # Compute standard deviation of centered ranks across estimation window
                        sd_rank = ranked_data %>%
                          dplyr::group_by(relative_index) %>%
                          dplyr::summarise(
                            mean_centered_rank = mean(centered_rank, na.rm = TRUE),
                            .groups = "drop"
                          )

                        S_rank = sd(sd_rank$mean_centered_rank, na.rm = TRUE)

                        # Event window statistics
                        aar_stats = ranked_data %>%
                          dplyr::filter(event_window == 1) %>%
                          dplyr::group_by(relative_index) %>%
                          dplyr::summarise(
                            aar            = mean(abnormal_returns, na.rm = TRUE),
                            n_events       = dplyr::n(),
                            n_valid_events = sum(!is.na(abnormal_returns)),
                            n_pos          = sum(abnormal_returns > 0, na.rm = TRUE),
                            n_neg          = sum(abnormal_returns <= 0, na.rm = TRUE),
                            mean_rank      = mean(centered_rank, na.rm = TRUE),
                            .groups = "drop"
                          ) %>%
                          dplyr::mutate(
                            rank_z = ifelse(is.finite(S_rank) & S_rank > 0,
                                            mean_rank / S_rank, NA_real_),
                            caar   = cumsum(dplyr::coalesce(aar, 0))
                          )

                        aar_stats$car_window = stringr::str_c("[", aar_stats$relative_index[1], ", ", aar_stats$relative_index, "]")
                        aar_stats
                      }
                    )
)


#' BMP Test (Boehmer, Musumeci, Poulsen 1991)
#'
#' Standardized cross-sectional test that is robust to event-induced variance
#' increases. The BMP test standardizes abnormal returns by their forecast
#' error corrected standard deviation, then applies a cross-sectional
#' t-test to these standardized residuals.
#'
#' @export
BMPTest <- R6Class("BMPTest",
                   inherit = TestStatisticBase,
                   public = list(
                     #' @field name Short code of the test statistic.
                     name = 'BMP',
                     #' @description
                     #' Computes the BMP standardized cross-sectional test.
                     #'
                     #' @param data_tbl The data for a multiple event with
                     #' calculated abnormal returns.
                     #' @param model The fitted model containing sigma estimates.
                     compute = function(data_tbl, model) {
                       # Extract sigma from each model
                       model = model %>%
                         dplyr::mutate(sigma = purrr::map_dbl(model, .f=function(x) {
                           x$statistics$sigma %||% NA_real_
                         }))

                       # Standardize abnormal returns by model sigma.
                       # Join on event_id, not firm_symbol: sigma is estimated
                       # per event, and a firm may appear in several events. A
                       # firm_symbol join is many-to-many and duplicates rows.
                       sar_data = data_tbl %>%
                         dplyr::filter(event_window == 1) %>%
                         dplyr::left_join(model %>% dplyr::select(event_id, sigma),
                                          by = "event_id") %>%
                         dplyr::mutate(sar = abnormal_returns / sigma)

                       # BMP test: cross-sectional t-test of SARs
                       aar_stats = sar_data %>%
                         dplyr::group_by(relative_index) %>%
                         dplyr::summarise(
                           aar            = mean(abnormal_returns, na.rm = TRUE),
                           n_events       = dplyr::n(),
                           n_valid_events = sum(!is.na(abnormal_returns)),
                           n_pos          = sum(abnormal_returns > 0, na.rm = TRUE),
                           n_neg          = sum(abnormal_returns <= 0, na.rm = TRUE),
                           mean_sar       = mean(sar, na.rm = TRUE),
                           sd_sar         = sd(sar, na.rm = TRUE),
                           bmp_t          = ifelse(is.finite(sd_sar) & sd_sar > 0,
                                                    sqrt(n_valid_events) * mean_sar / sd_sar,
                                                    NA_real_),
                           .groups = "drop"
                         ) %>%
                         dplyr::mutate(caar = cumsum(dplyr::coalesce(aar, 0)))

                       # Cumulative BMP
                       cum_sar = sar_data %>%
                         dplyr::select(event_id, relative_index, sar) %>%
                         dplyr::group_by(event_id) %>%
                         dplyr::mutate(csar = cumsum(dplyr::coalesce(sar, 0))) %>%
                         dplyr::group_by(relative_index) %>%
                         dplyr::summarise(
                           mean_csar = mean(csar, na.rm = TRUE),
                           sd_csar   = sd(csar, na.rm = TRUE),
                           n_valid   = sum(!is.na(csar)),
                           cbmp_t    = ifelse(is.finite(sd_csar) & sd_csar > 0,
                                              sqrt(n_valid) * mean_csar / sd_csar,
                                              NA_real_),
                           .groups = "drop"
                         )

                       aar_stats = aar_stats %>%
                         dplyr::left_join(cum_sar %>% dplyr::select(relative_index, cbmp_t),
                                          by = "relative_index")

                       aar_stats$car_window = stringr::str_c("[", aar_stats$relative_index[1], ", ", aar_stats$relative_index, "]")
                       aar_stats
                     }
                   )
)


#' Calendar-Time Portfolio Test
#'
#' Aggregates event-firm returns into calendar-time portfolios and tests
#' whether the portfolio intercept (alpha) is significantly different from
#' zero. This approach naturally handles cross-sectional dependence that
#' arises when events cluster in calendar time.
#'
#' For each relative event day, the test forms an equal-weighted portfolio
#' of all event firms' abnormal returns and computes a t-statistic of the
#' mean portfolio return.
#'
#' @export
CalendarTimePortfolioTest <- R6Class("CalendarTimePortfolioTest",
                                      inherit = TestStatisticBase,
                                      public = list(
                                        #' @field name Short code of the test statistic.
                                        name = 'CalTimeT',
                                        #' @description
                                        #' Computes the calendar-time portfolio test.
                                        #'
                                        #' @param data_tbl The data for multiple events with
                                        #' calculated abnormal returns.
                                        #' @param model The fitted models (unused directly).
                                        compute = function(data_tbl, model) {
                                          # Portfolio approach: for each relative event day,
                                          # form equal-weighted portfolio of ARs
                                          portfolio <- data_tbl %>%
                                            dplyr::filter(event_window == 1) %>%
                                            dplyr::group_by(relative_index) %>%
                                            dplyr::summarise(
                                              aar = mean(abnormal_returns, na.rm = TRUE),
                                              n_events = dplyr::n(),
                                              n_valid_events = sum(!is.na(abnormal_returns)),
                                              n_pos = sum(abnormal_returns >= 0, na.rm = TRUE),
                                              n_neg = sum(abnormal_returns < 0, na.rm = TRUE),
                                              port_sd = sd(abnormal_returns, na.rm = TRUE),
                                              .groups = "drop"
                                            )

                                          # Compute time-series t-stat of portfolio returns
                                          # under H0: E[AAR] = 0
                                          ts_sd <- sd(portfolio$aar, na.rm = TRUE)
                                          n_periods <- nrow(portfolio)

                                          portfolio <- portfolio %>%
                                            dplyr::mutate(
                                              caar = cumsum(dplyr::coalesce(aar, 0)),
                                              # Time-series t-stat: AAR_t / sd(AAR)
                                              caltime_t = ifelse(is.finite(ts_sd) & ts_sd > 0,
                                                                  aar / ts_sd, NA_real_),
                                              # CAAR t-stat: CAAR / (sd * sqrt(L))
                                              ccaltime_t = ifelse(is.finite(ts_sd) & ts_sd > 0,
                                                                   caar / (ts_sd * sqrt(seq_len(n_periods))),
                                                                   NA_real_)
                                            )

                                          portfolio$car_window <- stringr::str_c(
                                            "[", portfolio$relative_index[1], ", ",
                                            portfolio$relative_index, "]"
                                          )

                                          portfolio %>%
                                            dplyr::select(-port_sd)
                                        }
                                      )
)


#' Kolari-Pynnönen Adjusted BMP Test
#'
#' Adjusts the BMP (Boehmer, Musumeci, Poulsen 1991) test for cross-sectional
#' correlation of abnormal returns using the Kolari and Pynnönen (2010)
#' correction. The adjustment scales the BMP statistic by a factor that
#' accounts for the average pairwise correlation of standardized abnormal
#' residuals in the estimation window.
#'
#' @references
#' Kolari, J. W. and Pynnönen, S. (2010). Event Study Testing with
#' Cross-sectional Correlation of Abnormal Returns.
#' \emph{The Review of Financial Studies}, 23(11), 3996--4025.
#'
#' @export
KolariPynnonenTest <- R6Class("KolariPynnonenTest",
                               inherit = TestStatisticBase,
                               public = list(
                                 #' @field name Short code of the test statistic.
                                 name = 'KP',
                                 #' @description
                                 #' Computes the Kolari-Pynnönen adjusted BMP test.
                                 #'
                                 #' @param data_tbl The data for a multiple event with
                                 #' calculated abnormal returns.
                                 #' @param model The fitted model containing sigma estimates.
                                 compute = function(data_tbl, model) {
                                   # Extract sigma from each model
                                   model <- model %>%
                                     dplyr::mutate(sigma = purrr::map_dbl(model, .f = function(x) {
                                       x$statistics$sigma %||% NA_real_
                                     }))

                                   # Standardize abnormal returns by model sigma.
                                   # Join on event_id (see BMPTest): a firm_symbol
                                   # join is many-to-many when a firm recurs.
                                   sar_data <- data_tbl %>%
                                     dplyr::filter(event_window == 1) %>%
                                     dplyr::left_join(model %>% dplyr::select(event_id, sigma),
                                                      by = "event_id") %>%
                                     dplyr::mutate(sar = abnormal_returns / sigma)

                                   # --- BMP statistics (replicated from BMPTest) ---
                                   aar_stats <- sar_data %>%
                                     dplyr::group_by(relative_index) %>%
                                     dplyr::summarise(
                                       aar            = mean(abnormal_returns, na.rm = TRUE),
                                       n_events       = dplyr::n(),
                                       n_valid_events = sum(!is.na(abnormal_returns)),
                                       n_pos          = sum(abnormal_returns > 0, na.rm = TRUE),
                                       n_neg          = sum(abnormal_returns <= 0, na.rm = TRUE),
                                       mean_sar       = mean(sar, na.rm = TRUE),
                                       sd_sar         = sd(sar, na.rm = TRUE),
                                       bmp_t          = ifelse(is.finite(sd_sar) & sd_sar > 0,
                                                                sqrt(n_valid_events) * mean_sar / sd_sar,
                                                                NA_real_),
                                       .groups = "drop"
                                     ) %>%
                                     dplyr::mutate(caar = cumsum(dplyr::coalesce(aar, 0)))

                                   # Cumulative BMP
                                   cum_sar <- sar_data %>%
                                     dplyr::select(event_id, relative_index, sar) %>%
                                     dplyr::group_by(event_id) %>%
                                     dplyr::mutate(csar = cumsum(dplyr::coalesce(sar, 0))) %>%
                                     dplyr::group_by(relative_index) %>%
                                     dplyr::summarise(
                                       mean_csar = mean(csar, na.rm = TRUE),
                                       sd_csar   = sd(csar, na.rm = TRUE),
                                       n_valid   = sum(!is.na(csar)),
                                       cbmp_t    = ifelse(is.finite(sd_csar) & sd_csar > 0,
                                                           sqrt(n_valid) * mean_csar / sd_csar,
                                                           NA_real_),
                                       .groups = "drop"
                                     )

                                   # --- Kolari-Pynnönen correction ---
                                   # Compute average pairwise correlation of SARs from estimation window
                                   est_sar_data <- data_tbl %>%
                                     dplyr::filter(estimation_window == 1) %>%
                                     dplyr::left_join(model %>% dplyr::select(event_id, sigma),
                                                      by = "event_id") %>%
                                     dplyr::mutate(sar = abnormal_returns / sigma)

                                   # Pivot to wide: one column per event. Events,
                                   # not firms, are the cross-sectional units, so a
                                   # firm recurring in several events yields distinct
                                   # columns (a firm_symbol pivot would collide).
                                   est_sar_wide <- est_sar_data %>%
                                     dplyr::select(relative_index, event_id, sar) %>%
                                     tidyr::pivot_wider(names_from = event_id,
                                                        values_from = sar)

                                   # Compute correlation matrix of estimation-window SARs
                                   sar_matrix <- as.matrix(est_sar_wide[, -1])
                                   n_firms <- ncol(sar_matrix)

                                   if (n_firms >= 2) {
                                     cor_matrix <- stats::cor(sar_matrix, use = "pairwise.complete.obs")
                                     # Average off-diagonal correlation
                                     r_bar <- (sum(cor_matrix) - n_firms) / (n_firms * (n_firms - 1))
                                   } else {
                                     r_bar <- 0
                                   }

                                   # KP adjustment factor: sqrt((1 - r_bar) / (1 + (n-1)*r_bar))
                                   n <- aar_stats$n_valid_events[1]
                                   denom <- 1 + (n - 1) * r_bar
                                   numer <- 1 - r_bar
                                   if (is.finite(denom) && denom > 0 &&
                                       is.finite(numer) && numer >= 0) {
                                     kp_adj <- sqrt(numer / denom)
                                   } else {
                                     kp_adj <- 1
                                   }

                                   aar_stats <- aar_stats %>%
                                     dplyr::mutate(kp_t = bmp_t * kp_adj)

                                   aar_stats <- aar_stats %>%
                                     dplyr::left_join(
                                       cum_sar %>% dplyr::select(relative_index, cbmp_t),
                                       by = "relative_index"
                                     ) %>%
                                     dplyr::mutate(ckp_t = cbmp_t * kp_adj) %>%
                                     dplyr::select(-mean_sar, -sd_sar, -bmp_t, -cbmp_t)

                                   aar_stats$car_window <- stringr::str_c(
                                     "[", aar_stats$relative_index[1], ", ",
                                     aar_stats$relative_index, "]"
                                   )
                                   aar_stats
                                 }
                               )
)
